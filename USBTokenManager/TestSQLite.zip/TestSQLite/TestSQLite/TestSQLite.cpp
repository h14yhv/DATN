// TestSQLite.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <Windows.h>
#include <iostream>
#include "sqlite3.h"
#include <atlstr.h>
#include "list"
#include "vector"
#include "tchar.h"
#include "SQLiteCpp\SQLiteCpp.h"

using namespace std;

typedef struct _UNSIGNED_INFOMATION_
{
	DWORD dwPID;
	CStringW szPath;
	CStringW szSigner;
}USGN_INFO, *P_USGN_INFO;

list<USGN_INFO> retList;
void QueryDataBase(CHAR* szDatabase);
void CreateOpenDB(CHAR* szDatabase, list<USGN_INFO> retList);
int GetLastID(SQLite::Database db);

int main()
{
	CHAR szDatabase[MAX_PATH] = "scanner.db";
	USGN_INFO temp;
	temp.dwPID = 156;
	temp.szPath = L"C:\\Users\\Altair\\Documents\\visual studio 2013\\Projects\\TestSQLite\\TestSQLite\\1.exe";
	temp.szSigner = L"signer1";

	retList.push_back(temp);

	USGN_INFO temp2;
	temp2.dwPID = 2344;
	temp2.szPath = L"C:\\Users\\Altair\\Documents\\visual studio 2013\\Projects\\TestSQLite\\TestSQLite\\2.exe";
	temp2.szSigner = L"signer2";

	retList.push_back(temp2);

	CreateOpenDB(szDatabase, retList);
	QueryDataBase(szDatabase);
	return 0;
}

void QueryDataBase(CHAR* szDatabase)
{
	try
	{
		// Open a database file
		SQLite::Database    db(szDatabase);

		// Compile a SQL query, containing one parameter (index 1)
		SQLite::Statement   query(db, "SELECT * FROM AUTORUNS");

		// Bind the integer value 6 to the first parameter of the SQL query
		//query.bind(1, 6);

		// Loop to execute the query step by step, to get rows of result
		while (query.executeStep())
		{
			// Demonstrate how to get some typed column value
			int               id = query.getColumn(0);
			DWORD             pid = query.getColumn(1);
			const char*       path = query.getColumn(2);
			const char*       signer = query.getColumn(3);
			std::cout << "row: " << id << ", " << pid << ", " << path << ", " << signer << std::endl;
		}
	}
	catch (std::exception& e)
	{
		std::cout << "exception: " << e.what() << std::endl;
	}
}

void CreateOpenDB(CHAR* szDatabase, list<USGN_INFO> mylist)
{
	CStringW csSQL = _T("INSERT INTO AUTORUNS (ID,PID,PATH,SIGNER)");
	CStringW csTemp;
	TCHAR anhnh[MAX_PATH] = { 0 };
	TCHAR anhnh2[MAX_PATH] = { 0 };
	try
	{
		SQLite::Database    db(szDatabase, SQLite::OPEN_READWRITE | SQLite::OPEN_CREATE);
		// Delete table
		//db.exec("DROP TABLE IF EXISTS AUTORUNS");
		// Begin transaction
		SQLite::Transaction transaction(db);
		// Create New Table
		db.exec("CREATE TABLE IF NOT EXISTS AUTORUNS (ID INTEGER PRIMARY KEY NOT NULL, PID UNSIGNED BIG INT, PATH TEXT(260), SIGNER TEXT(260), UNIQUE(PID, PATH, SIGNER))"); //, PID INT, PATH TEXT(255), SIGNER TEXT(255)
		/////////////////////////////////////////////////////////////////////////////
		int  iLastID = 0;
		SQLite::Statement   query(db, "SELECT * FROM AUTORUNS ORDER BY ID DESC LIMIT 1;");

		while (query.executeStep())
		{
			iLastID = query.getColumn(0);
		}
		/////////////////////////////////////////////////////////////////////////////
		list<USGN_INFO>::iterator first_element;
		for (first_element = mylist.begin(); first_element != mylist.end(); first_element++)
		{
			iLastID++;
			//printf("========================================================\n");
			//printf("%ld\n", first_element->dwPID);
			//printf("%ls\n", first_element->szPath);
			//printf("%ls\n", first_element->szSigner);
			/*CStringW a;
			a.Format(L"%ld", first_element->dwPID);*/
			_stprintf_s(anhnh, _T("%ld"), first_element->dwPID);
			_stprintf_s(anhnh2, _T("%ld"), iLastID);
			csTemp += csSQL + " VALUES (" + anhnh2 + ",\'" + anhnh + "\',\'" + first_element->szPath + "\',\'" + first_element->szSigner + "\');";
			CStringA sql = CW2A(csTemp, CP_UTF8);
			int nb = db.exec(sql.GetBuffer());
			transaction.commit();
			csTemp.Empty();
		}


		// Commit transaction
		//transaction.commit();
	}
	catch (std::exception& e)
	{
		std::cout << "exception: " << e.what() << std::endl;
	}
}
