// TestSQLite.cpp : Defines the entry point for the console application.
//


void CUsingSQLite::QueryDataBase()
{
	try
	{
		// Open a database file
		SQLite::Database    db("C:\\db.db");

		// Compile a SQL query, containing one parameter (index 1)
		//SQLite::Statement   query(db, "SELECT * FROM DLL_UNSIGNED");
		SQLite::Statement   query(db, "SELECT * FROM COMPANY");
		// Bind the integer value 6 to the first parameter of the SQL query
		//query.bind(1, 6);

		// Loop to execute the query step by step, to get rows of result
		while (query.executeStep())
		{
			// Demonstrate how to get some typed column value
			int               id = query.getColumn(0);
			//DWORD             pid = query.getColumn(1);
			const char*       reg = query.getColumn(1);
			const char*       name = query.getColumn(2);
			const char*       path = query.getColumn(3);
			std::cout << "row: " << id << ", " << reg << ", " << name << ", " << path << std::endl;
		}
	}
	catch (std::exception& e)
	{
		std::cout << "exception: " << e.what() << std::endl;
	}
}

void Insert()
{
	char *sql;
	int nb = 0;
	try
	{
		SQLite::Database    db(szDatabase, SQLite::OPEN_READWRITE | SQLite::OPEN_CREATE);
		// Delete table
		db.exec("DROP TABLE IF EXISTS COMPANY");
		// Begin transaction
		SQLite::Transaction transaction(db);
		// Create New Table
		db.exec("CREATE TABLE IF NOT EXISTS COMPANY (ID INTEGER PRIMARY KEY NOT NULL, PID UNSIGNED BIG INT, PATH TEXT(1000), SIGNER TEXT(260), UNIQUE(PID, PATH, SIGNER))"); //, PID INT, PATH TEXT(255), SIGNER TEXT(255)
		/////////////////////////////////////////////////////////////////////////////
		int  iLastID = 0;
		SQLite::Statement   query(db, "SELECT * FROM COMPANY ORDER BY ID DESC LIMIT 1;");

		while (query.executeStep())
		{
			iLastID = query.getColumn(0);
		}

		sql = "INSERT INTO COMPANY (ID,NAME,AGE,ADDRESS,SALARY) "  \
         "VALUES (1, 'Paul', 32, 'California', 20000.00 ); " \
         "INSERT INTO COMPANY (ID,NAME,AGE,ADDRESS,SALARY) "  \
         "VALUES (2, 'Allen', 25, 'Texas', 15000.00 ); "     \
         "INSERT INTO COMPANY (ID,NAME,AGE,ADDRESS,SALARY)" \
         "VALUES (3, 'Teddy', 23, 'Norway', 20000.00 );" \
         "INSERT INTO COMPANY (ID,NAME,AGE,ADDRESS,SALARY)" \
         "VALUES (4, 'Mark', 25, 'Rich-Mond ', 65000.00 );";
		nb = db.exec(sql.GetBuffer());

		//// Commit transaction
		transaction.commit();
	}
	catch (std::exception& e)
	{
		std::cout << "exception: " << e.what() << std::endl;
	}
}